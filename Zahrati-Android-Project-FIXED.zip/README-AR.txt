مشروع زهرتي - تطبيق Android

طريقة البناء عبر GitHub Actions:
1) فك ضغط هذا الملف على جهازك أو ارفع محتويات المجلد إلى جذر مستودع GitHub (لا ترفع ملف ZIP وحده إذا كنت تريد تشغيل البناء تلقائياً).
2) تأكد أن settings.gradle و build.gradle ومجلد app ومجلد .github موجودة مباشرة في جذر المستودع.
3) افتح Actions ثم Build Zahrati APK ثم Run workflow، أو ادفع Commit جديداً.
4) بعد نجاح البناء، نزّل Artifact باسم Zahrati-debug-APK؛ بداخله app-debug.apk.

ملاحظة: هذا APK تجريبي Debug، وليس إصداراً موقّعاً للنشر على المتجر.
