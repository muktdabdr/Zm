const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)],C={...ZCFG,base:localStorage.zb||ZCFG.base},LOG=[];
const log=(...a)=>{LOG.push(new Date().toISOString().slice(11,19)+' '+a.join(' '));LOG.length>60&&LOG.shift()};
function toast(m){const t=$('#toast');t.textContent=m;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),3500)}
const NAV=[['home','🏠'],['gen','✨'],['ana','📷'],['lib','📚'],['draw','🎨'],['saved','💾'],['set','⚙️']];
$('#nav').innerHTML=NAV.map(n=>`<button data-g="${n[0]}">${n[1]}</button>`).join('');
function go(id){$$('.s').forEach(e=>e.hidden=e.id!=id);$$('#nav button').forEach(b=>b.classList.toggle('on',b.dataset.g==id));scrollTo(0,0);id=='saved'&&listSaved();id=='set'&&status()}
document.addEventListener('click',e=>{const b=e.target.closest('[data-g]');b&&go(b.dataset.g)});
// ---------- الاتصال بالخدمة ----------
let busy=false;
async function api(mode,payload){if(busy)throw new Error('هناك طلب قيد التنفيذ، انتظري انتهاءه');busy=true;const ac=new AbortController(),t=setTimeout(()=>ac.abort(),C.timeout);
 try{const r=await fetch(C.base+(C.paths[mode]||''),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({mode,...payload}),signal:ac.signal}),txt=await r.text();log(mode,r.status,txt.slice(0,300));
  if(r.status==429)throw new Error('وصلتِ حد الاستخدام، حاولي لاحقًا');
  if(r.status==400||r.status==401||r.status==403||r.status==422)throw new Error('رفضت الخدمة الطلب (HTTP '+r.status+'): '+txt.slice(0,120));
  if(!r.ok)throw new Error('فشل في الخادم (HTTP '+r.status+')');
  try{return JSON.parse(txt)}catch(e){throw new Error('استجابة غير صالحة (ليست JSON)')}
 }catch(e){log('ERR',e.name,e.message);if(e.name=='AbortError')throw new Error('انتهت مهلة الانتظار');if(e instanceof TypeError)throw new Error('تعذر الاتصال بالخدمة (إنترنت أو CORS)');throw e}finally{clearTimeout(t);busy=false}}
const pickImg=j=>{let v=j.image||j.imageUrl||j.url||j.b64||j.b64_json||(j.images&&j.images[0]);if(v&&typeof v!='string')v=v.url||v.b64_json||v.data;return v?(/^(data:|https?:)/.test(v)?v:'data:image/png;base64,'+v):null};
// ---------- خيارات + إنشاء ----------
const OPT={o_style:['النوع',['واقعي','realistic'],['كرتوني','cartoon'],['أنمي','anime'],['تخطيطي','sketch'],['هندسي','geometric'],['خطي','line art']],o_color:['اللون',['أبيض وأسود','black and white'],['خطوط سوداء فقط','pure black outlines on white background, no color, no gradients, no shadows'],['ملون','colored']],o_lvl:['الصعوبة',['مبتدئ','beginner, few details'],['متوسط','intermediate'],['متقدم','advanced'],['احترافي','professional, very precise']],o_ang:['الزاوية',['أمامي','front view'],['جانبي','side view'],['خلفي','back view'],['ثلاثة أرباع','three-quarter view'],['من الأعلى','top view']],o_bg:['الخلفية',['بيضاء','plain white background'],['بسيطة','simple background'],['طبيعية','natural background']],o_rat:['النسبة',['مربع','1:1'],['عمودي','3:4'],['أفقي','4:3']],o_det:['التفاصيل',['قليل','low detail'],['متوسط','medium detail'],['عالٍ','high detail']]};
$('#opts').innerHTML=Object.entries(OPT).map(([k,v])=>`<label>${v[0]}<select id="${k}"><option value="">حسب الوصف</option>${v.slice(1).map(o=>`<option value="${o[1]}">${o[0]}</option>`).join('')}</select></label>`).join('')+'<label>عدد العناصر<input type="text" id="cnt" inputmode="numeric" placeholder="تلقائي"></label>';
function spec(){const s={subject:$('#q').value.trim(),count:+$('#cnt').value||null};Object.keys(OPT).forEach(k=>{const v=$('#'+k).value;v&&(s[k.slice(2)]=v)});return s}
function promptOf(s){const L=['Draw exactly this subject, do not replace or add other subjects: '+s.subject];s.count&&L.push('Number of main subjects: '+s.count);['style','color','lvl','ang','bg','det'].forEach(k=>s[k]&&L.push(k+': '+s[k]));L.push('No people, faces, text or watermarks unless the subject asks for them.');return L.join('\n')}
function busyUI(btn,msgEl,on,msg){btn.disabled=on;msgEl.textContent=msg||''}
$('#go').onclick=async()=>{const s=spec();if(!s.subject)return toast('اكتبي وصف الرسم أولًا');busyUI($('#go'),$('#gs'),true,'جاري إنشاء الصورة...');$('#gr').innerHTML='';
 try{const j=await api('generate',{prompt:promptOf(s),spec:s,subject:s.subject}),img=pickImg(j);if(!img)throw new Error('الخدمة لم تُرجع صورة. على الأرجح لا يوجد في الـ Worker مسار لتوليد الصور، افحصي السجل في «حالة الخدمة».');
  $('#gs').textContent='تم. ملاحظة: لا يوجد تحقق آلي من مطابقة الصورة للوصف، راجعيها بنفسك.';
  $('#gr').innerHTML=`<img src="${img}" crossorigin="anonymous"><div class="row"><button id="g1">🎓 درس</button><button id="g2">🎨 مرجع للرسم</button><button id="g3">💾 حفظ</button></div>`;
  $('#g1').onclick=()=>lessonFrom(img,s.subject,$('#gs'));$('#g2').onclick=()=>{setRef(img);go('draw')};$('#g3').onclick=()=>saveItem(img,s.subject)
 }catch(e){$('#gs').textContent='❌ '+e.message+'\n(يمكنك إعادة المحاولة؛ مساحة الرسم والمكتبة تعملان دون إنترنت)'}finally{$('#go').disabled=false}};
// ---------- تحليل الصور والمراحل ----------
const loadImg=src=>new Promise((res,rej)=>{const i=new Image();i.crossOrigin='anonymous';i.onload=()=>res(i);i.onerror=()=>rej(new Error('تعذر تحميل الصورة'));i.src=src});
function edges(c,th){const x=c.getContext('2d'),w=c.width,h=c.height,d=x.getImageData(0,0,w,h),g=new Float32Array(w*h),o=x.createImageData(w,h);o.data.fill(255);for(let i=0;i<w*h;i++)g[i]=.3*d.data[i*4]+.59*d.data[i*4+1]+.11*d.data[i*4+2];
 for(let y=1;y<h-1;y++)for(let X=1;X<w-1;X++){const i=y*w+X,gx=g[i+1-w]+2*g[i+1]+g[i+1+w]-g[i-1-w]-2*g[i-1]-g[i-1+w],gy=g[i+w-1]+2*g[i+w]+g[i+w+1]-g[i-w-1]-2*g[i-w]-g[i-w+1];if(Math.hypot(gx,gy)>th){const k=i*4;o.data[k]=o.data[k+1]=o.data[k+2]=30}}x.putImageData(o,0,0);return c}
function mk(img,f,fn){const c=document.createElement('canvas');c.width=360;c.height=Math.round(360*img.height/img.width);const x=c.getContext('2d');x.fillStyle='#fff';x.fillRect(0,0,c.width,c.height);x.filter=f;x.drawImage(img,0,0,c.width,c.height);x.filter='none';return(fn?fn(c):c).toDataURL('image/jpeg',.85)}
function localStages(img){return[['الكتل الكبيرة','تجاهلي التفاصيل وارسمي الشكل العام كبقع وأشكال بسيطة.',mk(img,'grayscale(1) blur(14px) contrast(.8)')],['الخطوط الرئيسية','ارسمي الحدود الخارجية والخطوط الأكبر فقط.',mk(img,'blur(3px)',c=>edges(c,90))],['التفاصيل','أضيفي الخطوط الداخلية الأدق بعد ثبات الشكل.',mk(img,'blur(1px)',c=>edges(c,45))],['الظلال','ظلّلي المناطق الداكنة بالتدرج من الفاتح إلى الداكن.',mk(img,'grayscale(1) contrast(1.4)')],['النتيجة النهائية','قارني رسمك بالصورة الأصلية وصحّحي النسب.',mk(img,'none')]]}
async function lessonFrom(src,subject,msgEl){busyUI($('#an'),msgEl,true,'جاري تحليل الصورة وتجهيز مراحل الرسم...');
 try{const img=await loadImg(src),loc=localStages(img),sm=mk(img,'none');let st,note;
  try{const j=await api('analyze',{subject:subject||'',image:sm.split(',')[1],mime:'image/jpeg'}),a=j.stages||j.steps;if(!Array.isArray(a)||a.length<2)throw new Error('الخدمة لم تُرجع مراحل');
   st=a.map((s,i)=>({t:s.title||s.name||('المرحلة '+(i+1)),d:typeof s=='string'?s:(s.text||s.description||s.instruction||''),img:loc[Math.round(i*4/(a.length-1))][2]}));note='مراحل من تحليل الخدمة، والصور التوضيحية معالجة محليًا.'
  }catch(e){if(!confirm('فشل التحليل: '+e.message+'\nهل تريدين مراحل تقريبية محلية؟ (ليست تحليلًا حقيقيًا لموضوع الصورة)'))throw new Error('أُلغي الدرس. '+e.message);st=loc.map(s=>({t:s[0],d:s[1],img:s[2]}));note='مراحل تقريبية محلية، وليست تحليلًا حقيقيًا للصورة.'}
  openLesson({ref:sm,st,note});msgEl.textContent=''
 }catch(e){msgEl.textContent='❌ '+e.message}finally{$('#an').disabled=false}}
let CUR=null;const cr={l:0,t:0,w:100,h:100};
function pick(f){if(!f)return;const r=new FileReader();r.onload=async()=>{try{CUR=await loadImg(r.result);$('#prev').hidden=$('#crop').hidden=false;drawPrev()}catch(e){toast(e.message)}};r.readAsDataURL(f)}
$('#f1').onchange=e=>pick(e.target.files[0]);$('#f2').onchange=e=>pick(e.target.files[0]);
$('#crop').innerHTML=[['l','من اليسار %',0,80],['t','من الأعلى %',0,80],['w','العرض %',20,100],['h','الارتفاع %',20,100]].map(a=>`<label>${a[1]}<input type="range" data-k="${a[0]}" min="${a[2]}" max="${a[3]}" value="${cr[a[0]]}"></label>`).join('');
$('#crop').oninput=e=>{cr[e.target.dataset.k]=+e.target.value;drawPrev()};
function cropped(max){const W=CUR.width,H=CUR.height,sx=W*cr.l/100,sy=H*cr.t/100,sw=Math.min(W-sx,W*cr.w/100),sh=Math.min(H-sy,H*cr.h/100),k=Math.min(1,max/Math.max(sw,sh)),c=document.createElement('canvas');c.width=sw*k;c.height=sh*k;c.getContext('2d').drawImage(CUR,sx,sy,sw,sh,0,0,c.width,c.height);return c}
function drawPrev(){const c=cropped(300),p=$('#prev');p.width=c.width;p.height=c.height;p.getContext('2d').drawImage(c,0,0)}
$('#an').onclick=()=>{if(!CUR)return toast('اختاري صورة أولًا');lessonFrom(cropped(1024).toDataURL('image/jpeg',.9),$('#asub').value.trim(),$('#as'))};
// ---------- عارض الدرس ----------
let L=null;
function openLesson(l){L={...l,i:0};go('les');rl()}
function rl(){const s=L.st[L.i];$('#lref').src=L.ref;$('#limg').src=s.img;$('#lt').textContent=s.t;$('#ld').textContent=s.d||'';$('#lnote').textContent=L.note||'';$('#lc').textContent=(L.i+1)+' / '+L.st.length;$('#lp').disabled=!L.i;$('#ln').disabled=L.i==L.st.length-1}
$('#lp').onclick=()=>{L.i--;rl()};$('#ln').onclick=()=>{L.i++;rl()};$('#lf').onclick=()=>{L.i=L.st.length-1;rl()};$('#lr').onclick=()=>{L.i=0;rl()};$('#ld2').onclick=()=>{setRef(L.st[L.i].img);go('draw')};
// ---------- المكتبة (رسومات SVG فعلية) ----------
const SV=g=>'data:image/svg+xml,'+encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200"><rect width="200" height="200" fill="#fff"/><g fill="none" stroke="#111" stroke-width="3" stroke-linecap="round" stroke-linejoin="round">'+g.join('')+'</g></svg>');
const G=s=>`<g stroke="#999" stroke-dasharray="5 6" stroke-width="2">${s}</g>`;
const LIB=[{n:'وردة',c:'الورود والنباتات',lv:'مبتدئ',s:[['الأشكال الأساسية','دائرة للزهرة، وخط مستقيم للساق، وخطان مائلان لمكان الورقتين.',G('<circle cx="100" cy="70" r="42"/><path d="M100 112V190M100 150l-35-20M100 135l35-20"/>')],['البتلات','بتلة وسطى كقطرة ثم بتلتان تلتفان حولها.','<path d="M100 42c-22 4-34 26-18 44 9 9 27 9 36 0 16-18 4-40-18-44z"/><path d="M68 62c-14 18-4 42 22 50M132 62c14 18 4 42-22 50"/>'],['الساق والأوراق','ساق منحنية قليلًا وورقتان بشكل قطرة.','<path d="M100 112c-3 30 3 52 0 78"/><path d="M100 150c-34-4-44-26-44-26s34-6 44 26z"/><path d="M100 135c26-4 40-22 40-22s-30-4-40 22z"/>'],['التفاصيل','خطوط البتلات الداخلية.','<path d="M90 58c7 9 17 9 24 0M86 78c9 7 21 7 30 0"/>']]},
{n:'بيت',c:'البيوت والمباني',lv:'مبتدئ',s:[['الأشكال الأساسية','مستطيل للجسم ومثلث للسقف.',G('<path d="M40 95h120v85H40zM30 95L100 40l70 55"/>')],['الجسم والسقف','ثبّتي الجسم والسقف بخط واضح.','<path d="M40 95V180H160V95"/><path d="M28 98L100 36l72 62z"/>'],['الباب والنوافذ','باب في الوسط ونافذتان متقابلتان.','<path d="M90 130h24v50H90zM55 112h22v22H55zM123 112h22v22h-22z"/>'],['التفاصيل','مدخنة وتقسيم النوافذ.','<path d="M126 55V32h14v36M66 112v22M55 123h22M134 112v22M123 123h22"/>']]},
{n:'شجرة',c:'الأشجار والطبيعة',lv:'مبتدئ',s:[['الأشكال الأساسية','خط للجذع ودائرة كبيرة للتاج.',G('<path d="M100 190V120"/><circle cx="100" cy="80" r="55"/>')],['الجذع والتاج','جذع عريض من الأسفل وتاج بحواف متموجة.','<path d="M90 190V125M110 190V125M80 190H120"/><path d="M60 85c-18-15-8-42 14-40 8-20 40-22 50-2 22-4 34 24 16 40 6 20-18 36-34 28-14 10-40 4-46-26z"/>'],['الأغصان','أغصان داخل التاج تتفرع من الجذع.','<path d="M100 125V95M100 108L80 90M100 105l18-16"/>'],['الأوراق','أقواس صغيرة توحي بكثافة الأوراق.','<path d="M75 70c5-5 10-5 14 0M115 60c5-5 10-5 14 0M95 85c5-5 10-5 14 0"/>']]},
{n:'سيارة جانبية',c:'السيارات والمركبات',lv:'متوسط',s:[['الأشكال الأساسية','مستطيل للهيكل ودائرتان للعجلتين على خط واحد.',G('<path d="M20 95h160v45H20z"/><circle cx="55" cy="145" r="20"/><circle cx="145" cy="145" r="20"/>')],['الهيكل','سقف مائل وخط سفلي بينهما قوسان للعجلات.','<path d="M20 140V110l25-8 25-30h60l25 30 25 8v30h-15M35 140H20M75 140h50"/>'],['العجلات','دائرة خارجية وأخرى صغيرة لكل عجلة.','<circle cx="55" cy="145" r="18"/><circle cx="145" cy="145" r="18"/><circle cx="55" cy="145" r="7"/><circle cx="145" cy="145" r="7"/>'],['النوافذ والتفاصيل','نافذة بخط مائل وفاصل ومصابيح.','<path d="M78 76h42l16 26H62zM100 76v26M172 112h8M20 112h8"/>']]}];
function libLesson(it){const n=it.s.length,st=it.s.map((s,i)=>({t:s[0],d:s[1],img:SV(it.s.slice(0,i+1).map(x=>x[2]))}));st.push({t:'تنظيف الخطوط',d:'امسحي خطوط البناء المنقطة وأبقي الخطوط النهائية.',img:SV(it.s.slice(1).map(x=>x[2]))});openLesson({ref:st[n].img,st,note:'رسم SVG من مكتبة التطبيق.'})}
$('#libg').innerHTML=[...new Set(LIB.map(i=>i.c))].map(c=>`<h3>${c}</h3><div class="grid2">${LIB.map((it,k)=>it.c==c?`<div class="card lc"><img src="${SV(it.s.map(x=>x[2]))}"><b>${it.n}</b><br><small>${it.lv}</small><button data-l="${k}" style="width:100%;margin-top:6px">ابدئي الدرس</button></div>`:'').join('')}</div>`).join('');
$('#libg').onclick=e=>{const b=e.target.closest('[data-l]');b&&libLesson(LIB[b.dataset.l])};
// ---------- مساحة الرسم ----------
const cv=$('#cv'),cx=cv.getContext('2d');cv.width=540;cv.height=720;let tool='pen',dn=false,H=[],R=[],lx,ly;
const snap=()=>{H.push(cx.getImageData(0,0,540,720));H.length>20&&H.shift();R=[]},pos=e=>{const r=cv.getBoundingClientRect();return[(e.clientX-r.left)*540/r.width,(e.clientY-r.top)*720/r.height]};
function stroke(a,b,c,d){cx.globalCompositeOperation=tool=='er'?'destination-out':'source-over';cx.strokeStyle=$('#col').value;cx.lineWidth=+$('#sz').value;cx.lineCap=cx.lineJoin='round';cx.beginPath();cx.moveTo(a,b);cx.lineTo(c,d);cx.stroke()}
cv.onpointerdown=e=>{if(tool=='hand')return;e.preventDefault();cv.setPointerCapture(e.pointerId);snap();dn=true;[lx,ly]=pos(e);stroke(lx,ly,lx,ly)};
cv.onpointermove=e=>{if(!dn)return;const[x,y]=pos(e);stroke(lx,ly,x,y);lx=x;ly=y};cv.onpointerup=cv.onpointercancel=()=>dn=false;
$$('[data-t]').forEach(b=>b.onclick=()=>{tool=b.dataset.t;$$('[data-t]').forEach(x=>x.classList.toggle('on',x==b));cv.style.touchAction=tool=='hand'?'auto':'none'});
$('#un').onclick=()=>{if(H.length){R.push(cx.getImageData(0,0,540,720));cx.putImageData(H.pop(),0,0)}};$('#re').onclick=()=>{if(R.length){H.push(cx.getImageData(0,0,540,720));cx.putImageData(R.pop(),0,0)}};
$('#cl').onclick=()=>{snap();cx.clearRect(0,0,540,720)};$('#op').oninput=e=>$('#dref').style.opacity=e.target.value/100;$('#zm').oninput=e=>$('#stage').style.width=e.target.value*100+'%';$('#gd').onchange=e=>$('#grid').hidden=!e.target.checked;
function setRef(s){$('#dref').src=s;$('#dref').style.opacity=$('#op').value/100}
$('#fr').onchange=e=>{const f=e.target.files[0];if(f){const r=new FileReader();r.onload=()=>setRef(r.result);r.readAsDataURL(f)}};
function png(){const t=document.createElement('canvas');t.width=540;t.height=720;const x=t.getContext('2d');x.fillStyle='#fff';x.fillRect(0,0,540,720);x.drawImage(cv,0,0);return t.toDataURL('image/png')}
$('#dl').onclick=()=>{const u=png();if(window.ZA){ZA.save(u.split(',')[1])}else{const a=document.createElement('a');a.href=u;a.download='zahrati.png';a.click()}};
$('#sv').onclick=()=>saveItem(png(),prompt('اسم الرسم:','رسمي')||'رسم بدون اسم');
// ---------- التخزين المحلي IndexedDB ----------
const dbp=new Promise((res,rej)=>{const r=indexedDB.open('zahrati',1);r.onupgradeneeded=()=>r.result.createObjectStore('d',{keyPath:'id'});r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error)});
const tx=async(m,f)=>{const d=await dbp;return new Promise((res,rej)=>{const t=d.transaction('d',m),q=f(t.objectStore('d'));t.oncomplete=()=>res(q&&q.result);t.onerror=()=>rej(t.error)})};
async function saveItem(data,name){try{await tx('readwrite',s=>s.put({id:Date.now(),name,data,fav:false,t:Date.now()}));toast('تم الحفظ في رسوماتي')}catch(e){toast('تعذر الحفظ: '+e.message)}}
let favOnly=false;
async function listSaved(){let a=await tx('readonly',s=>s.getAll())||[];a.sort((x,y)=>y.t-x.t);favOnly&&(a=a.filter(x=>x.fav));$('#sl').innerHTML=a.length?a.map(x=>`<div class="card lc"><img src="${x.data}"><b>${x.name}</b><div class="row"><button data-a="o" data-i="${x.id}">فتح</button><button data-a="f" data-i="${x.id}">${x.fav?'⭐':'☆'}</button><button data-a="r" data-i="${x.id}">✏️</button><button data-a="d" data-i="${x.id}">🗑️</button></div></div>`).join(''):'<p>لا توجد رسومات بعد.</p>'}
$('#sl').onclick=async e=>{const b=e.target.closest('[data-a]');if(!b)return;const id=+b.dataset.i,x=await tx('readonly',s=>s.get(id));if(!x)return;
 if(b.dataset.a=='o'){const i=await loadImg(x.data);cx.clearRect(0,0,540,720);cx.drawImage(i,0,0);go('draw')}
 else{if(b.dataset.a=='f')x.fav=!x.fav;if(b.dataset.a=='r')x.name=prompt('الاسم الجديد:',x.name)||x.name;if(b.dataset.a=='d'){if(!confirm('حذف الرسم؟'))return;await tx('readwrite',s=>s.delete(id))}else await tx('readwrite',s=>s.put(x));listSaved()}};
$('#ff').onclick=()=>{favOnly=!favOnly;listSaved()};$('#cd').onclick=async()=>{if(confirm('حذف كل الرسومات والإعدادات المحلية؟')){await tx('readwrite',s=>s.clear());localStorage.clear();listSaved();toast('تم الحذف')}};
// ---------- حالة الخدمة ----------
$('#burl').value=C.base;$('#bs').onclick=()=>{localStorage.zb=$('#burl').value.trim().replace(/\/$/,'');C.base=localStorage.zb;toast('تم حفظ العنوان')};$('#bt').onclick=status;
async function status(){const el=$('#st');el.textContent='جاري الفحص...';const ac=new AbortController(),t=setTimeout(()=>ac.abort(),8000);try{const r=await fetch(C.base,{signal:ac.signal}),x=await r.text();log('ping',r.status,x.slice(0,200));el.textContent='✅ الخادم يستجيب (HTTP '+r.status+')\n'+x.slice(0,300)}catch(e){el.textContent='❌ تعذر الوصول: '+e.message}clearTimeout(t);$('#lg').textContent=LOG.join('\n')||'(لا سجل بعد)'}
go('home');
