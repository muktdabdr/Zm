// إعدادات الربط بالخدمة. غيّري المسارات هنا فقط إذا كان الـ Worker يستخدم مسارات مختلفة.
window.ZCFG={base:'https://rasmi-ai.muktdabdr.workers.dev',paths:{generate:'',analyze:''},timeout:45000};
