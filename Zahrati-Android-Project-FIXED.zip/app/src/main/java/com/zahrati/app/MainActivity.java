package com.zahrati.app;
import android.app.Activity;import android.content.ContentValues;import android.content.Intent;import android.net.Uri;import android.os.Bundle;import android.provider.MediaStore;import android.util.Base64;import android.webkit.*;import android.widget.Toast;import androidx.webkit.WebViewAssetLoader;import java.io.OutputStream;
public class MainActivity extends Activity{
 WebView w;ValueCallback<Uri[]> cb;
 class Br{@JavascriptInterface public void save(String b64){try{ContentValues v=new ContentValues();v.put(MediaStore.MediaColumns.DISPLAY_NAME,"zahrati_"+System.currentTimeMillis()+".png");v.put(MediaStore.MediaColumns.MIME_TYPE,"image/png");v.put(MediaStore.MediaColumns.RELATIVE_PATH,"Pictures/Zahrati");Uri u=getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,v);OutputStream o=getContentResolver().openOutputStream(u);o.write(Base64.decode(b64,0));o.close();t("تم الحفظ في المعرض (Pictures/Zahrati)")}catch(Exception e){t("تعذر الحفظ: "+e.getMessage())}}}
 void t(String m){runOnUiThread(()->Toast.makeText(this,m,Toast.LENGTH_LONG).show())}
 @Override protected void onCreate(Bundle b){super.onCreate(b);w=new WebView(this);setContentView(w);
  final WebViewAssetLoader l=new WebViewAssetLoader.Builder().addPathHandler("/assets/",new WebViewAssetLoader.AssetsPathHandler(this)).build();
  WebSettings s=w.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);
  w.addJavascriptInterface(new Br(),"ZA");
  w.setWebViewClient(new WebViewClient(){@Override public WebResourceResponse shouldInterceptRequest(WebView v,WebResourceRequest r){return l.shouldInterceptRequest(r.getUrl())}});
  w.setWebChromeClient(new WebChromeClient(){@Override public boolean onShowFileChooser(WebView v,ValueCallback<Uri[]> c,FileChooserParams p){if(cb!=null)cb.onReceiveValue(null);cb=c;try{startActivityForResult(p.createIntent(),1)}catch(Exception e){cb=null;return false}return true}});
  w.loadUrl("https://appassets.androidplatform.net/assets/index.html");}
 @Override protected void onActivityResult(int r,int c,Intent d){if(r==1&&cb!=null){cb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(c,d));cb=null}}
 @Override public void onBackPressed(){if(w.canGoBack())w.goBack();else super.onBackPressed()}
}
