زهرتي: تطبيق رسم وتعليم رسم
1) فكّي الضغط وارفعي محتويات المجلد (وليس الـ zip نفسه) إلى مستودع GitHub، بما فيها مجلد .github.
2) افتحي Actions ثم Build APK ثم Run workflow، وحمّلي Zahrati-APK من Artifacts.
3) واجهة الويب في app/src/main/assets (index.html وapp.js وconfig.js وstyle.css) وتعمل في Spck أيضًا.
4) عنوان الـ Worker ومساراته في config.js. يجب أن يرد الـ Worker برؤوس CORS (Access-Control-Allow-Origin: *).
5) لا توجد مفاتيح سرية في الملفات؛ مفاتيح Gemini وClaude تبقى في أسرار Cloudflare.
