# زهرتي — مشروع Android (WebView)

## المحتويات
- `app/src/main/assets/index.html` : التطبيق كاملاً (واجهة + منطق). عدّلي هذا الملف لتغيير التطبيق.
- `app/src/main/java/.../MainActivity.java` : غلاف WebView، يدعم اختيار الصور وحفظ PNG في Pictures/Zahrati.
- `settings.gradle`, `build.gradle`, `app/build.gradle` : إعدادات البناء (AGP 8.5.2، Gradle 8.9، Java 17).

## البناء من الهاتف (GitHub Actions)
1. أنشئي مستودعاً على GitHub.
2. ارفعي `Zahrati-Android-Project-FIXED.zip` (كما هو، بدون فك) إلى جذر المستودع.
3. أنشئي الملف `.github/workflows/main.yml` وألصقي فيه محتوى `main.yml`.
4. من تبويب Actions شغّلي «Zahrati APK»، ثم نزّلي `Zahrati-debug-APK` من Artifacts.
5. فكّي الأرشيف وثبّتي `app-debug.apk` (فعّلي التثبيت من مصدر غير معروف).

## خدمة الذكاء الاصطناعي
- عنوان الخادم مضبوط داخل `index.html` (المتغير `API`): `https://rasmi-ai.muktdabdr.workers.dev`.
- يلزم نشر `worker-v10.js` على Cloudflare، وربط Workers AI باسم `AI`، وإضافة الأسرار:
  `GEMINI_API_KEY`, `GROQ_API_KEY`, `OPENROUTER_API_KEY`, `ANTHROPIC_API_KEY`.
- لا توجد مفاتيح داخل التطبيق.

## ملاحظات
- تعديل الواجهة وحده لا يكفي لتحسين مطابقة الصور للوصف؛ قواعد المطابقة موجودة في `worker-v10.js`.
- لا يوجد تحقق آلي من مطابقة الصورة المولّدة للوصف، ولا يضمن أي نموذج مطابقة كاملة.

## الكاميرا
- في لوحة الرسم: «الكاميرا» تشغّل الكاميرا الخلفية خلف الرسم، و«الفلاش» يشغّل الإضاءة إن كان الجهاز يدعمها.
- يطلب التطبيق إذن الكاميرا عند أول تشغيل.
